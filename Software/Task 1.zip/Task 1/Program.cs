﻿using System;

namespace Task_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            testUlong();
            //Ввід: 0 (мінімальне значення ulong)
            //Вивід: 0
            //Перевірка: 0
            //Кількість одиничних бітів: 0
            //
            //Ввід: 99
            //Вивід: 1100011
            //Перевірка: 1100011
            //Кількість одиничних бітів: 4
            //
            //Ввід: 18446744073709551615 (максимальне значення ulong)
            //Вивід: 1111111111111111111111111111111111111111111111111111111111111111
            //Перевірка: 1111111111111111111111111111111111111111111111111111111111111111
            //Кількість одиничних бітів: 64
        }

        /// <summary>
        /// Тестує ввід, два варіанти бінарного представлення
        /// і вивід кількості одиничних бітів числа
        /// </summary>
        static void testUlong()
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.WriteLine("Введіть число: ");
            ulong u = ulong.Parse(Console.ReadLine());

            string s = convertUlongToBinaryString(u);
            int[] arr = convertUlongToBinaryArray(u);

            Console.WriteLine("Перший спосіб (стрічка): ");
            Console.WriteLine(s);
            Console.WriteLine("Другий спосіб (масив): ");
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write(arr[i]);
            }

            checkUlong(u);

            Console.WriteLine("Кількість одиниць в двійковому представленні: " + countOneBits(u));
        }

        /// <summary>
        /// Конвертує змінну ulong в бінарне представлення
        /// з використанням StringBuilder
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string convertUlongToBinaryString(ulong value)
        {
            if (value == 0) return "0";

            System.Text.StringBuilder b = new System.Text.StringBuilder();
            while (value != 0)
            {
                b.Insert(0, ((value & 1) == 1) ? '1' : '0');
                value >>= 1;
            }
            return b.ToString();
        }

        /// <summary>
        /// Конвертує змінну ulong в бінарне представлення з
        /// використанням масиву для збереження значень бітів
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static int[] convertUlongToBinaryArray(ulong value)
        {
            ulong mask = 1;
            ulong temp = value;
            int[] binaryArr = new int[64]; 

            while ((temp >>= 1) >= 1)
            {
                mask <<= 1;
            }

            for (int i = 0; i < 64; i++)
            {
                binaryArr[i] = (((value & mask) != 0) ? 1 : 0);
                value <<= 1;
            }
            return binaryArr;
        }

        /// <summary>
        /// Перевіряє бінарне представлення числа з
        /// використанням бібліотечної функції Convert.ToString 
        /// </summary>
        /// <param name="value"></param>
        static void checkUlong(ulong value)
        {
            string result = Convert.ToString((long)value, 2);
            Console.WriteLine("\nПеревірка через вбудовану функцію: ");
            Console.WriteLine(result);
        }

        /// <summary>
        /// Підраховує кількість одиничних бітів у 
        /// бінарному представленні числа
        /// </summary>
        /// <param name="u"></param>
        /// <returns></returns>
        static int countOneBits(ulong u)
        {
            int count = 0;
            while (u > 0)
            {
                count += (int)(u & 1);
                u >>= 1;
            }
            return count;
        }
    }
}
