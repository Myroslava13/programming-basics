﻿using System;

namespace Task_3
{
    internal class Program
    {
        // Переведення з 10-ї системи в 2-ву
        // Ввід: -1.23
        // Вивід: -1.0011101011
        // Ввід: 0.56
        // Вивід: 0.1000111101
        // 
        // Переведення з 2-ї системи в 10-ву
        // Ввід: 110.101
        // Вивід: 6.625
        // Ввід: -101.1101
        // Вивід: -5.8125
        // 
        // Додавання двох чисел в 2-ій системі
        // Ввід числа 1: 1011.01
        // Ввід числа 2: 11.011
        // Вивід: 1110.101
        // 
        // Віднімання двох чисел в 2-ій системі
        // Ввід числа 1: 10101.101
        // Ввід числа 2: 1011.110
        // Вивід: 1001.111
        static void Main(string[] args)
        {
            //Console.Write(
            //    Binary.decimalToBinary(-1.23, 10) + "\n");

            //Console.Write(
            //    Binary.decimalToBinary(0.56, 10) + "\n");

            //string n = "110.101";
            //Console.Write(
            //    Binary.binaryToDecimal(n, n.Length) + "\n");

            //n = "-101.1101";
            //Console.Write(
            //    Binary.binaryToDecimal(n, n.Length));

            //Binary binary1 = new Binary();
            //Binary binary2 = new Binary();
            //string n1 = "1011.01";
            //string n2 = "11.011";
            //binary1.FillInBits(n1, n1.Length);
            //binary2.FillInBits(n2, n2.Length);

            //Binary binary3 = binary1 + binary2;
            //binary3.PrintBits();

            Binary binary4 = new Binary();
            Binary binary5 = new Binary();
            string n3 = "10101.101";
            string n4 = "1011.110";
            binary4.FillInBits(n3, n3.Length);
            binary5.FillInBits(n4, n4.Length);

            Binary binary6 = binary4 - binary5;
            binary6.PrintBits();
        }
    }
}
