﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_3
{
    /// <summary>
    /// Клас для проведення обчислень
    /// у 2-ій системі
    /// </summary>
    public class Binary
    {
        /// <summary>
        /// Список, де зберігаються значення бітів
        /// </summary>
        List<int> bits;
        public int Length { get => bits.Count; }
        public int decimalPoint;
        int sign;

        /// <summary>
        /// Конструктор, в якому ініціалізується
        /// список, де зберігаються значення бітів
        /// </summary>
        public Binary()
        {
            bits = new List<int>();
        }

        /// <summary>
        /// Переводить чисто з 10-ї системи в 2-ву
        /// </summary>
        /// <param name="num"></param>
        /// <param name="k_prec">Задана точність</param>
        /// <returns></returns>
        public static string decimalToBinary(double num, int k_prec)
        {
            string binary = "";
            double numcpy = num;

            num = Math.Abs(num);
            int Integral = (int)num;
            double fractional = num - Integral;

            if (Integral == 0)
                binary += '0';

            while (Integral > 0)
            {
                int rem = Integral % 2;
                binary += ((char)(rem + '0'));
                Integral /= 2;
            }
            binary = reverse(binary);
            binary += ('.');

            while (k_prec-- > 0)
            {
                fractional *= 2;
                int fract_bit = (int)fractional;

                if (fract_bit == 1)
                {
                    fractional -= fract_bit;
                    binary += (char)(1 + '0');
                }
                else
                {
                    binary += (char)(0 + '0');
                }
            }

            if (numcpy < 0)
                binary = binary.Insert(0, "-");

            return binary;
        }

        /// <summary>
        /// Допоміжний метод для обертання стрічки
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static string reverse(string input)
        {
            char[] temparray = input.ToCharArray();
            int left, right = 0;
            right = temparray.Length - 1;

            for (left = 0; left < right; left++, right--)
            {
                char temp = temparray[left];
                temparray[left] = temparray[right];
                temparray[right] = temp;
            }
            return string.Join("", temparray);
        }

        /// <summary>
        /// Переводить число з 2-ї системи в 10-ву
        /// </summary>
        /// <param name="binary"></param>
        /// <param name="len"></param>
        /// <returns></returns>
        public static double binaryToDecimal(string binary, int len)
        {
            int sign = (binary[0] == '-') ? -1 : 1;

            if (sign == -1)
            {
                binary = binary.Trim('-');
                len--;
            }

            int point = binary.IndexOf('.');
            if (point == -1)
                point = len;

            double intDecimal = 0,
                   fracDecimal = 0,
                   twos = 1;

            for (int i = point - 1; i >= 0; i--)
            {
                intDecimal += (binary[i] - '0') * twos;
                twos *= 2;
            }

            twos = 2;
            for (int i = point + 1; i < len; i++)
            {
                fracDecimal += (binary[i] - '0') / twos;
                twos *= 2.0;
            }

            return sign * (intDecimal + fracDecimal);
        }

        /// <summary>
        /// Заповнює значення бітів числа у 
        /// 2-ій системі
        /// </summary>
        /// <param name="binary"></param>
        /// <param name="len"></param>
        public void FillInBits(string binary, int len)
        {
            this.bits.Clear();
            this.sign = (binary[0] == '-') ? -1 : 1;
            if (sign == -1)
            {
                binary = binary.Trim('-');
                len--;
            }

            int point = binary.IndexOf('.');
            if (point == -1)
                point = len;

            this.decimalPoint = point;

            for (int i = 0; i < len; i++)
            {
                if (binary[i] != '.')
                    bits.Add(int.Parse(binary[i].ToString()));
            }
        }

        /// <summary>
        /// Виводить число у 2-ій системі
        /// на консоль
        /// </summary>
        public void PrintBits()
        {
            if (this.sign == -1)
                Console.Write("-");

            for (int i = 0; i < bits.Count; i++)
            {
                if (i == decimalPoint)
                    Console.Write(".");
                Console.Write(bits[i]);
            }
        }

        /// <summary>
        /// Допоміжний метод для коректування
        /// розміру двійкових чисел
        /// </summary>
        /// <param name="num1"></param>
        /// <param name="num2"></param>
        public static void AdjustSize(ref Binary num1, ref Binary num2)
        {
            if (num1.Length < num2.Length)
            {
                List<int> temp = new List<int>();
                temp = num1.bits;
                num1.bits = num2.bits;
                num2.bits = temp;
            }

            int diff = num1.Length - num2.Length;

            for (int i = 0; i < diff; i++)
            {
                num1.bits.Add(0);
            }

            diff = num1.Length - num2.Length;

            for (int k = 0; k < diff; k++)
            {
                num2.bits.Insert(k, 0);
                num2.decimalPoint++;
            }
        }

        /// <summary>
        /// Перевизначена операція додавання
        /// двох чисел у 2-ій системі
        /// </summary>
        /// <param name="num1"></param>
        /// <param name="num2"></param>
        /// <returns></returns>
        public static Binary operator +(Binary num1, Binary num2)
        {
            int rem = 0;

            AdjustSize(ref num1, ref num2);

            Binary binaryNum = new Binary();
            int i = num1.Length - 1, j = i;

            while (i >= 0 || j >= 0)
            {
                binaryNum.bits.Insert(0, (int)((num1.bits[i] % 10 + num2.bits[j] % 10 + rem) % 2));
                rem = (int)((num1.bits[i] % 10 + num2.bits[j] % 10 + rem) / 2);
                i--; j--;
            }
            if (rem != 0 && i >= 0)
            {
                binaryNum.bits.Insert(i--, rem);
            }
            binaryNum.decimalPoint = num1.decimalPoint;
            binaryNum.sign = num1.sign;
            return binaryNum;
        }

        /// <summary>
        /// Перевизначена операція віднімання
        /// двох чисел у 2-ій системі
        /// </summary>
        /// <param name="num1"></param>
        /// <param name="num2"></param>
        /// <returns></returns>
        public static Binary operator -(Binary num1, Binary num2)
        {
            string s1 = "", s2 = "";
            for (int i = 0; i < num1.Length; i++)
            {
                if (i == num1.decimalPoint)
                    s1 += ".";
                s1 += num1.bits[i].ToString();
            }

            for (int i = 0; i < num2.Length; i++)
            {
                if (i == num2.decimalPoint)
                    s2 += ".";
                s2 += num2.bits[i].ToString();
            }

            double dec1 = binaryToDecimal(s1, s1.Length),
                   dec2 = binaryToDecimal(s2, s2.Length);

            double result = dec1 - dec2;
            string s3 = decimalToBinary(result, 10);

            Binary binary = new Binary();
            binary.decimalPoint = s3.IndexOf('.');

            for (int i = 0; i < s3.Length - 1; i++)
            {
                if (s3[i] != '.')
                    binary.bits.Add(int.Parse(s3[i].ToString()));
            }

            return binary;
        }
    }
}

