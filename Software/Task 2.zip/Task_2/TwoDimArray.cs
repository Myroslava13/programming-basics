﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HDF5DotNet;

namespace Task_2
{
    /// <summary>
    /// Клас <c>TwoDimArray</c> для проведення операцій 
    /// з 2Д і зубчатими масивами
    /// </summary>
    public class TwoDimArray
    {
        /// <summary>
        /// Читає 2Д масив з файлу
        /// </summary>
        /// <returns>int[,] result</returns>
        public static int[,] ReadFromTextFile()
        {
            var path = Path.Combine(Directory.GetCurrentDirectory(), "test.txt");
            String input = File.ReadAllText(path);

            int i = 0, j = 0;
            int[,] result = new int[10, 10];
            foreach (var row in input.Split('\n'))
            {
                j = 0;
                foreach (var col in row.Trim().Split(' '))
                {
                    result[i, j] = int.Parse(col.Trim());
                    j++;
                }
                i++;
            }
            return result;
        }

        /// <summary>
        /// Записує 2Д масив в .h5 файл з використанням
        /// сторонньої бібліотеки HDF5DotNet
        /// </summary>
        /// <param name="arr"></param>
        public static void WriteToHDF5File(int[,] arr)
        {
            int firstDim = arr.GetLength(0);
            int secondDim = arr.GetLength(1);

            var path = Path.Combine(Directory.GetCurrentDirectory(), "array.h5");
            var datasetName = "array";
            var fileId =
                H5F.create(path, H5F.CreateMode.ACC_TRUNC);

            var dataSpaceId =
                H5S.create_simple(2, new long[] { firstDim, secondDim });
            var datasetId =
                H5D.create(fileId, datasetName, new H5DataTypeId(H5T.H5Type.NATIVE_INT), dataSpaceId);

            H5D.write<int>(datasetId, new H5DataTypeId(H5T.H5Type.NATIVE_INT), new H5Array<int>(arr));

            H5D.close(datasetId);
            H5F.close(fileId);
        }

        /// <summary>
        /// Конвертує 2Д масив в зубчатий
        /// </summary>
        /// <param name="twoDimArr"></param>
        /// <returns></returns>
        public static int[][] ToJaggedArray(int[,] twoDimArr)
        {
            int rows1stIdx = twoDimArr.GetLowerBound(0);
            int rowsLastIdx = twoDimArr.GetUpperBound(0);
            int rowsCount = rowsLastIdx + 1;

            int cols1stIdx = twoDimArr.GetLowerBound(1);
            int colsLastIdx = twoDimArr.GetUpperBound(1);
            int colsCount = colsLastIdx + 1;

            int[][] jaggedArr = new int[rowsCount][];
            for (int i = rows1stIdx; i <= rowsLastIdx; i++)
            {
                jaggedArr[i] = new int[colsCount];

                for (int j = cols1stIdx; j <= colsLastIdx; j++)
                {
                    jaggedArr[i][j] = twoDimArr[i, j];
                }
            }
            return jaggedArr;
        }

        /// <summary>
        /// Створює зубчатий масив та заповнює
        /// його випадковими числами
        /// </summary>
        /// <returns>int[][] result</returns>
        public static int[][] FillJaggedArray()
        {
            Random random = new Random();
            int[][] result = new int[100][];

            for (int i = 0; i < result.Length; i++)
            {
                result[i] = new int[100];
                for (int j = 0; j < result[i].Length; j++)
                {
                    result[i][j] = random.Next(100);
                }
            }
            return result;
        }

        /// <summary>
        /// Створює 2Д масив та заповнює
        /// його випадковими числами
        /// </summary>
        /// <returns>int[,] result</returns>
        public static int[,] Fill2DArray()
        {
            Random random = new Random();
            int[,] result = new int[100, 100];

            for (int i = 0; i < result.GetLength(0); i++)
            {
                for (int j = 0; j < result.GetLength(1); j++)
                {
                    result[i, j] = random.Next(100);
                }
            }
            return result;
        }

        /// <summary>
        /// Друкує зубчатий масив на консоль
        /// </summary>
        /// <param name="jaggedArr"></param>
        public static void PrintJaggedArray(int[][] jaggedArr)
        {
            for (int i = 0; i < jaggedArr.Length; i++)
            {
                for (int j = 0; j < jaggedArr[i].Length; j++)
                {
                    Console.Write(jaggedArr[i][j] + " ");
                }
                Console.WriteLine();
            }
        }

        /// <summary>
        /// Друкує 2Д масив на консоль
        /// </summary>
        /// <param name="twoDimArr"></param>
        public static void Print2DArray(int[,] twoDimArr)
        {
            for (int i = 0; i < twoDimArr.GetLength(0); i++)
            {
                for (int j = 0; j < twoDimArr.GetLength(1); j++)
                {
                    Console.Write(twoDimArr[i, j] + " ");
                }
                Console.WriteLine();
            }
        }
    }
}
