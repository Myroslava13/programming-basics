﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_2
{
    /// <summary>
    /// Клас <c>MultiplyMatrixes</c> для множення
    /// матриць в 2Д і зубчатому форматах
    /// </summary>
    public class MultiplyMatrixes
    {
        /// <summary>
        /// Множить дві 2Д матриці
        /// </summary>
        /// <param name="m1">матриця 1</param>
        /// <param name="m2">матриця 2</param>
        /// <returns></returns>
        /// <exception cref="ArgumentException">
        /// Виникає, коли матриці не можуть бути помножені
        /// </exception>
        public static int[,] Multiply2DMatrixes(int[,] m1, int[,] m2)
        {
            if (m1.GetLength(1) != m2.GetLength(0))
            {
                throw new ArgumentException("Неможливо помножити дані матриці");
            }

            var result = new int[m1.GetLength(0), m2.GetLength(1)];
            for (int i = 0; i < m1.GetLength(0); i++)
            {
                for (int j = 0; j < m2.GetLength(1); j++)
                {
                    for (var k = 0; k < m1.GetLength(1); k++)
                    {
                        result[i, j] += m1[i, k] * m2[k, j];
                    }
                }
            }
            return result;
        }

        /// <summary>
        /// Множить дві зубчаті матриці
        /// </summary>
        /// <param name="m1">матриця 1</param>
        /// <param name="m2">матриця 2</param>
        /// <returns></returns>
        /// <exception cref="ArgumentException"></exception>
        /// Виникає, коли матриці не можуть бути помножені
        /// </exception>
        public static int[][] MultiplyJaggedMatrixes(int[][] m1, int[][] m2)
        {
            if (m1[0].Length != m2.Length)
            {
                throw new ArgumentException("Неможливо помножити дані матриці");
            }

            var result = new int[m1.Length][];
            for (int i = 0; i < m1.Length; i++)
            {
                result[i] = new int[m2[0].Length];
                for (int j = 0; j < m2[i].Length; j++)
                {
                    for (var k = 0; k < m1[i].Length; k++)
                    {
                        result[i][j] += m1[i][k] * m2[k][j];
                    }
                }
            }
            return result;
        }
    }
}
