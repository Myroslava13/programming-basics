﻿using System;
using System.Diagnostics;

namespace Task_2
{
    internal class Program
    {
        // Результати:
        // Вивід: 2Д масив, прочитаний з файлу
        // Вивід: зубчатий масив, отриманий з вкзаного 2Д масиву
        // Вивід:
        // Час, витрачений на множення зубчатих матриць:
        // 27.3933 53.0609 70.0379 87.7644 102.6538 116.5746 127.1625 136.8374 149.3008 160.2304
        // Час, витрачений на множення 2D матриць:
        // 34.2526 62.7769 100.7015 126.885 185.6313 251.8991 313.625 373.6378 437.7905 530.2952
        //
        // Висновок: швидкодія множення зубчатих матриць більша, ніж багатовимірних

        static void Main(string[] args)
        {
            testArrayToHDF5(testConvertArray());
            testJaggedMultiplication();
            test2DMultiplication();
        }

        /// <summary>
        /// Читає двовимірний масив з файлу, конвертує
        /// його в зубчатий, виводить обидва масиви
        /// </summary>
        /// <returns>int[,] twoDimArr</returns>
        static int[,] testConvertArray()
        {
            int[,] twoDimArr = TwoDimArray.ReadFromTextFile();
            Console.WriteLine("2D масив:");
            TwoDimArray.Print2DArray(twoDimArr);

            int[][] jaggedArr = TwoDimArray.ToJaggedArray(twoDimArr);
            Console.WriteLine("Зубчатий масив:");
            TwoDimArray.PrintJaggedArray(jaggedArr);

            return twoDimArr;
        }

        /// <summary>
        /// Викликає запис двовимірного масиву в .h5 файл
        /// </summary>
        static void testArrayToHDF5(int [,] twoDimArr)
        {
            TwoDimArray.WriteToHDF5File(twoDimArr);
        }

        /// <summary>
        /// Обчислює швидкодію множення зубчатих матриць
        /// використовуючи клас Stopwatch
        /// </summary>
        static void testJaggedMultiplication()
        {
            int[][] arr1;
            int[][] arr2;

            double[] time = new double[10];
            int[][] result;

            var timer = new Stopwatch();
            for (int i = 0; i < 10; i++)
            {
                arr1 = TwoDimArray.FillJaggedArray();
                arr2 = TwoDimArray.FillJaggedArray();

                timer.Start();
                result = MultiplyMatrixes.MultiplyJaggedMatrixes(arr1, arr2);
                timer.Stop();
                time[i] = timer.Elapsed.TotalMilliseconds;
            }

            Console.WriteLine("Час, витрачений на множення зубчатих матриць:");
            for (int i = 0; i < 10; i++)
            {
                Console.Write(time[i] + " ");
            }
            Console.WriteLine();
        }

        /// <summary>
        /// Обчислює швидкодію множення 2Д матриць
        /// використовуючи клас Stopwatch
        /// </summary>
        static void test2DMultiplication()
        {
            int[,] arr1;
            int[,] arr2;

            double[] time = new double[10];
            int[,] result;

            var timer = new Stopwatch();
            for (int i = 0; i < 10; i++)
            {
                arr1 = TwoDimArray.Fill2DArray();
                arr2 = TwoDimArray.Fill2DArray();

                timer.Start();
                result = MultiplyMatrixes.Multiply2DMatrixes(arr1, arr2);
                timer.Stop();
                time[i] = timer.Elapsed.TotalMilliseconds;
            }

            Console.WriteLine("Час, витрачений на множення 2D матриць:");
            for (int i = 0; i < 10; i++)
            {
                Console.Write(time[i] + " ");
            }
            Console.WriteLine();
            Console.ReadLine();
        }
    }
}
