﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_4
{
    /// <summary>
    /// Клас для роботи з матрицею
    /// </summary>
    public class Matrix
    {
        /// <summary>
        /// Двовимірний масив (матриця)
        /// </summary>
        double [,] m;
        int size;

        /// <summary>
        /// Конструктор. Читає розмір матриці, 
        /// елементи та виводить матрицю на консоль
        /// </summary>
        public Matrix()
        {
            ReadSize();
            ReadMatrix();
            PrintMatrix();
        }

        /// <summary>
        /// Читає розмір матриці з клавіатури
        /// </summary>
        public void ReadSize()
        {
            Console.WriteLine("Введіть розмір: ");
            size = int.Parse(Console.ReadLine());
        }

        /// <summary>
        /// Читає значення елементів матриці
        /// з клавіатури
        /// </summary>
        public void ReadMatrix()
        {
            m = new double[size, size];
            Console.WriteLine();
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    Console.Write($"m[{i + 1}][{j + 1}] = ");
                    m[i, j] = double.Parse(Console.ReadLine());
                }
            }
        }

        /// <summary>
        /// Виводить матрицю на консоль
        /// </summary>
        void PrintMatrix()
        {
            Console.WriteLine();
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    Console.Write(m[i, j] + " ");
                }
                Console.WriteLine();
            }
        }

        /// <summary>
        /// Обчислює норму Фробеніуса (корінь квадратний
        /// із суми квадратів елементів матриці)
        /// </summary>
        /// <returns></returns>
        public double CalculateMatrixNorm()
        {
            double sum = 0;
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    sum += Math.Pow(m[i, j], 2);
                }
            }
            return Math.Sqrt(sum);
        }
    }
}
