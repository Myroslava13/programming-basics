﻿using System;

namespace Task_4
{
    internal class Program
    {
        // Ввід (матриця 3х3):
        // { { 1, 1, 1 }, { 1, 1, 1 }, { 1, 1, 1 } }
        // Вивід: Норма матриці = 3
        //
        // Ввід (матриця 4х4):
        // { { -1, 2, 6, 0 }, { 3, -3, 4, 1 }, { 0, 4, 8, 5 }, { -6, 0, 4, -7 } }
        // Вивід: Норма матриці = 16.792855623746664
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Matrix m = new Matrix();
            Console.WriteLine();
            Console.WriteLine("Норма матриці = " + m.CalculateMatrixNorm());
        }
    }
}
